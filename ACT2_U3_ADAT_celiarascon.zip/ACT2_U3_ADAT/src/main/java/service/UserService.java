package service;


import entity.UsersObject;
import org.hibernate.Session;

import java.util.List;

public class UserService {

    public static void createUser(Session session, String name) {
        session.beginTransaction();
        UsersObject user = new UsersObject();
        user.setName(name);
        session.persist(user);
        session.getTransaction().commit();
        System.out.println("Usuario creado con éxito: " + name);
    }

    public static UsersObject findUserById(Session session, int userId) {
        return session.get(UsersObject.class, userId);
    }

    public static List<UsersObject> findAllUsers(Session session) {
        return session.createQuery("FROM UsersObject", UsersObject.class).list();
    }

    public static void updateUser(Session session, int userId, String newName) {
        UsersObject user = findUserById(session, userId);
        if (user != null) {
            session.beginTransaction();
            user.setName(newName);
            session.merge(user);
            session.getTransaction().commit();
            System.out.println("Usuario actualizado correctamente: " + newName);
        } else {
            System.out.println("Usuario no encontrado con ID: " + userId);
        }
    }

    public static void deleteUser(Session session, int userId) {
        UsersObject user = findUserById(session, userId);
        if (user != null) {
            session.beginTransaction();
            session.remove(user);
            session.getTransaction().commit();
            System.out.println("Usuario eliminado con éxito: " + userId);
        } else {
            System.out.println("Usuario no encontrado con ID: " + userId);
        }
    }
}

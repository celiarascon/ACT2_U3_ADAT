package service;

import entity.TicketsObject;
import entity.UsersObject;
import org.hibernate.Session;

import java.math.BigDecimal;
import java.util.List;

public class TicketService {

    public static void createTicket(Session session, String nombreAtraccion, BigDecimal price, int userId) {
        UsersObject user = UserService.findUserById(session, userId);
        if (user != null) {
            String hql = "FROM TicketsObject WHERE user.id = :userId AND nombreAtraccion = :nombreAtraccion";
            TicketsObject existingTicket = session.createQuery(hql, TicketsObject.class)
                    .setParameter("userId", userId)
                    .setParameter("nombreAtraccion", nombreAtraccion)
                    .uniqueResult();

            if (existingTicket == null) {
                session.beginTransaction();
                TicketsObject ticket = new TicketsObject();
                ticket.setNombreAtraccion(nombreAtraccion);
                ticket.setPrice(price);
                ticket.setUser(user);
                session.persist(ticket);
                session.getTransaction().commit();
                System.out.println("Ticket creado con éxito para la atracción: " + nombreAtraccion);
            } else {
                System.out.println("El ticket ya existe para la atracción: " + nombreAtraccion);
            }
        } else {
            System.out.println("No se encontró el usuario con ID: " + userId);
        }
    }


    public static List<TicketsObject> findAllTickets(Session session) {
        return session.createQuery("FROM TicketsObject", TicketsObject.class).list();
    }

    public static List<TicketsObject> findTicketsByUser(Session session, int userId) {
        String hql = "FROM TicketsObject WHERE user.id = :userId";
        return session.createQuery(hql, TicketsObject.class)
                .setParameter("userId", userId)
                .list();
    }

    public static List<TicketsObject> findTicketsByAttraction(Session session, String nombreAtraccion) {
        String hql = "FROM TicketsObject WHERE nombreAtraccion = :nombreAtraccion";
        return session.createQuery(hql, TicketsObject.class)
                .setParameter("nombreAtraccion", nombreAtraccion)
                .list();
    }

    public static void deleteTicket(Session session, int ticketId) {
        TicketsObject ticket = session.get(TicketsObject.class, ticketId);
        if (ticket != null) {
            session.beginTransaction();
            session.remove(ticket);
            session.getTransaction().commit();
            System.out.println("Ticket eliminado con éxito.");
        } else {
            System.out.println("No se encontró el ticket con ID: " + ticketId);
        }
    }
}

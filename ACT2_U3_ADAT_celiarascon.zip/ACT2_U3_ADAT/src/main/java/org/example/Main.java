package org.example;

import org.hibernate.Session;
import service.TicketService;
import service.UserService;

import java.math.BigDecimal;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try (Session session = HibernateUtil.getSession()) {
            UserService.createUser(session, "Juan");
            UserService.createUser(session, "Maria");

            List<entity.UsersObject> users = UserService.findAllUsers(session);
            System.out.println("Usuarios actuales:");
            users.forEach(user -> System.out.println("ID: " + user.getId() + ", Nombre: " + user.getName()));

            TicketService.createTicket(session, "Carroza Grande", BigDecimal.valueOf(5.00), 1);
            TicketService.createTicket(session, "Montaña Rusa", BigDecimal.valueOf(8.50), 1);
            TicketService.createTicket(session, "Caseta del Terror", BigDecimal.valueOf(7.00), 2);

            System.out.println("Tickets actuales:");
            TicketService.findAllTickets(session).forEach(ticket ->
                    System.out.println("ID: " + ticket.getId() +
                            ", Atracción: " + ticket.getNombreAtraccion() +
                            ", Precio: " + ticket.getPrice()));

            System.out.println("Tickets de Juan:");
            TicketService.findTicketsByUser(session, 1).forEach(ticket ->
                    System.out.println("Atracción: " + ticket.getNombreAtraccion() +
                            ", Precio: " + ticket.getPrice()));

            System.out.println("Entradas para 'Montaña Rusa':");
            TicketService.findTicketsByAttraction(session, "Montaña Rusa").forEach(ticket ->
                    System.out.println("ID: " + ticket.getId() +
                            ", Usuario: " + ticket.getUser().getName() +
                            ", Precio: " + ticket.getPrice()));

            UserService.updateUser(session, 1, "Juan Actualizado");

            TicketService.deleteTicket(session, 1);

            UserService.deleteUser(session, 2);

        } catch (Exception e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
        }
    }
}
